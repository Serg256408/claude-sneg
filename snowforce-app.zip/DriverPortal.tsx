import React, { useState, useMemo, useCallback, useRef, useEffect } from 'react';
import { Order, OrderStatus, TripEvidence, Contractor, AssetType, DriverAssignment, formatPrice, formatDateTime, generateId } from './types';

interface DriverPortalProps {
  orders: Order[];
  contractors: Contractor[];
  driverName: string;
  driverContractorId: string;
  onReportTrip: (orderId: string, evidence: TripEvidence) => void;
  onAcceptJob: (orderId: string, contractorId: string, assetType: AssetType) => void;
  onFinishWork: (orderId: string) => void;
}

interface GeoPosition {
  latitude: number;
  longitude: number;
  accuracy: number;
}

const DriverPortal: React.FC<DriverPortalProps> = ({
  orders,
  contractors,
  driverName,
  driverContractorId,
  onReportTrip,
  onAcceptJob,
  onFinishWork
}) => {
  const [selectedOrder, setSelectedOrder] = useState<{ order: Order; type: AssetType } | null>(null);
  const [activeTab, setActiveTab] = useState<'mine' | 'public' | 'company' | 'earnings'>('mine');
  const [isCapturing, setIsCapturing] = useState(false);
  const [currentPosition, setCurrentPosition] = useState<GeoPosition | null>(null);
  const [geoError, setGeoError] = useState<string | null>(null);
  const [photoType, setPhotoType] = useState<'loading' | 'full_truck' | 'unloading' | 'ticket'>('loading');
  const [capturedPhotos, setCapturedPhotos] = useState<{ type: string; url: string; timestamp: string }[]>([]);
  const [showPhotoPreview, setShowPhotoPreview] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Получение геолокации
  useEffect(() => {
    if (navigator.geolocation) {
      const watchId = navigator.geolocation.watchPosition(
        (position) => {
          setCurrentPosition({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy
          });
          setGeoError(null);
        },
        (error) => {
          setGeoError(`Ошибка GPS: ${error.message}`);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 }
      );
      return () => navigator.geolocation.clearWatch(watchId);
    }
  }, []);

  // Мои активные работы
  const myJobs = useMemo(() => orders.filter(o =>
    o.assignedDrivers.includes(driverName) &&
    o.status !== OrderStatus.CANCELLED &&
    o.status !== OrderStatus.COMPLETED
  ), [orders, driverName]);

  // Публичная биржа
  const publicBoard = useMemo(() => {
    const list: { order: Order; type: AssetType }[] = [];
    orders.forEach(o => {
      if (!o.isBirzhaOpen || o.status === OrderStatus.COMPLETED || o.status === OrderStatus.CANCELLED) return;
      o.assetRequirements.filter(req => !req.contractorId).forEach(req => {
        const assigned = (o.driverDetails || []).filter(d => d.assetType === req.type && !d.contractorId).length;
        if (assigned < req.plannedUnits && !(o.driverDetails || []).some(d => d.driverName === driverName && d.assetType === req.type)) {
          list.push({ order: o, type: req.type });
        }
      });
    });
    return list;
  }, [orders, driverName]);

  // Прямые предложения от подрядчика
  const companyBoard = useMemo(() => {
    const list: { order: Order; type: AssetType }[] = [];
    if (!driverContractorId) return list;
    orders.forEach(o => {
      if (o.status === OrderStatus.COMPLETED || o.status === OrderStatus.CANCELLED) return;
      o.assetRequirements.filter(req => req.contractorId === driverContractorId).forEach(req => {
        const assigned = (o.driverDetails || []).filter(d => d.assetType === req.type && d.contractorId === driverContractorId).length;
        if (assigned < req.plannedUnits && !(o.driverDetails || []).some(d => d.driverName === driverName && d.assetType === req.type)) {
          list.push({ order: o, type: req.type });
        }
      });
    });
    return list;
  }, [orders, driverName, driverContractorId]);

  // Расчёт заработка
  const earningsData = useMemo(() => {
    let totalPreliminary = 0;
    let totalConfirmed = 0;
    let totalTrips = 0;
    let confirmedTrips = 0;

    orders.forEach(o => {
      const myEvidences = (o.evidences || []).filter(e => e.driverName === driverName);
      const myAssignment = (o.driverDetails || []).find(d => d.driverName === driverName);
      
      if (myAssignment && myEvidences.length > 0) {
        const pricePerTrip = myAssignment.assignedPrice || 
          o.assetRequirements.find(r => r.type === myAssignment.assetType)?.contractorPrice || 0;
        
        totalTrips += myEvidences.length;
        confirmedTrips += myEvidences.filter(e => e.confirmed).length;
        totalPreliminary += myEvidences.length * pricePerTrip;
        totalConfirmed += myEvidences.filter(e => e.confirmed).length * pricePerTrip;
      }
    });

    return { totalPreliminary, totalConfirmed, totalTrips, confirmedTrips };
  }, [orders, driverName]);

  const displayJobs = activeTab === 'mine' 
    ? myJobs.map(j => ({ order: j, type: (j.driverDetails || []).find(d => d.driverName === driverName)?.assetType || AssetType.TRUCK }))
    : activeTab === 'public' ? publicBoard : companyBoard;

  // Обработка фото
  const handleFileCapture = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.[0]) return;
    
    setIsCapturing(true);
    const file = e.target.files[0];
    
    // Проверка даты фото (EXIF) - базовая проверка по lastModified
    const photoDate = new Date(file.lastModified);
    const now = new Date();
    const hoursDiff = (now.getTime() - photoDate.getTime()) / (1000 * 60 * 60);
    
    if (hoursDiff > 24) {
      alert('⚠️ Внимание: Фотография сделана более 24 часов назад. Рекомендуется сделать свежее фото.');
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const newPhoto = {
        type: photoType,
        url: reader.result as string,
        timestamp: new Date().toISOString()
      };
      setCapturedPhotos(prev => [...prev, newPhoto]);
      setIsCapturing(false);
    };
    reader.readAsDataURL(file);
    
    // Сбрасываем input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }, [photoType]);

  // Отправка рейса
  const submitTrip = useCallback(() => {
    if (!selectedOrder || capturedPhotos.length === 0) {
      alert('Необходимо сделать хотя бы одно фото!');
      return;
    }

    const activeOrder = orders.find(o => o.id === selectedOrder.order.id);
    if (!activeOrder) return;

    const tripNumber = (activeOrder.evidences || []).filter(e => e.driverName === driverName).length + 1;

    const evidence: TripEvidence = {
      id: generateId(),
      orderId: activeOrder.id,
      tripNumber,
      driverName,
      timestamp: new Date().toISOString(),
      coordinates: currentPosition || undefined,
      photos: capturedPhotos,
      photoValidation: {
        isRecent: true,
        isInGeofence: true, // Можно добавить реальную проверку геозоны
        validationErrors: []
      },
      confirmed: false
    };

    onReportTrip(activeOrder.id, evidence);
    setCapturedPhotos([]);
    setShowPhotoPreview(false);
    alert('✅ Рейс отправлен на проверку!');
  }, [selectedOrder, capturedPhotos, currentPosition, driverName, orders, onReportTrip]);

  // Текущий выбранный заказ (обновлённый)
  const activeSelectedOrder = selectedOrder
    ? orders.find(o => o.id === selectedOrder.order.id)
    : null;

  const driverEvidences = activeSelectedOrder
    ? (activeSelectedOrder.evidences || []).filter(e => e.driverName === driverName)
    : [];

  const confirmedCount = driverEvidences.filter(e => e.confirmed).length;
  const pendingCount = driverEvidences.filter(e => !e.confirmed).length;

  // Заработок по текущему заказу
  const currentOrderEarnings = useMemo(() => {
    if (!activeSelectedOrder) return { preliminary: 0, confirmed: 0 };
    
    const myAssignment = (activeSelectedOrder.driverDetails || []).find(d => d.driverName === driverName);
    const pricePerTrip = myAssignment?.assignedPrice ||
      activeSelectedOrder.assetRequirements.find(r => r.type === selectedOrder?.type)?.contractorPrice || 0;
    
    return {
      preliminary: driverEvidences.length * pricePerTrip,
      confirmed: confirmedCount * pricePerTrip
    };
  }, [activeSelectedOrder, driverEvidences, confirmedCount, driverName, selectedOrder]);

  const photoTypeLabels = {
    loading: '📦 Погрузка',
    full_truck: '🚛 Полный кузов',
    unloading: '📤 Выгрузка',
    ticket: '🎫 Талон'
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0f1d] text-white font-['Inter']">
      {/* HEADER */}
      <div className="p-4 bg-[#12192c] border-b border-white/5 shadow-2xl sticky top-0 z-30">
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-700 rounded-xl flex items-center justify-center font-black text-xl shadow-lg">
              {driverName.charAt(0)}
            </div>
            <div>
              <h2 className="text-sm font-black uppercase truncate max-w-[180px]">{driverName}</h2>
              <div className="flex items-center gap-2">
                <span className={`w-2 h-2 rounded-full ${currentPosition ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></span>
                <p className="text-[8px] text-slate-400 font-bold uppercase tracking-widest">
                  {currentPosition ? 'GPS активен' : 'GPS недоступен'}
                </p>
              </div>
            </div>
          </div>
          
          {/* Мини-статистика */}
          <div className="text-right">
            <div className="text-lg font-black text-green-400">{formatPrice(earningsData.totalConfirmed)}</div>
            <div className="text-[8px] text-slate-500 uppercase">Подтверждено</div>
          </div>
        </div>

        {/* Табы */}
        <div className="grid grid-cols-4 bg-[#1c2641] p-1 rounded-xl border border-white/5 gap-1">
          <button 
            onClick={() => { setActiveTab('mine'); setSelectedOrder(null); }} 
            className={`py-2.5 text-[8px] font-black uppercase rounded-lg transition-all flex flex-col items-center gap-1 ${activeTab === 'mine' ? 'bg-white text-slate-900 shadow-xl' : 'text-slate-500'}`}
          >
            <span>🚛</span>
            <span>В работе</span>
            {myJobs.length > 0 && <span className="bg-blue-500 text-white text-[7px] px-1.5 rounded-full">{myJobs.length}</span>}
          </button>
          <button 
            onClick={() => { setActiveTab('company'); setSelectedOrder(null); }} 
            className={`py-2.5 text-[8px] font-black uppercase rounded-lg transition-all flex flex-col items-center gap-1 ${activeTab === 'company' ? 'bg-orange-500 text-white shadow-xl' : 'text-slate-500'}`}
          >
            <span>📨</span>
            <span>Прямые</span>
            {companyBoard.length > 0 && <span className="bg-orange-400 text-white text-[7px] px-1.5 rounded-full">{companyBoard.length}</span>}
          </button>
          <button 
            onClick={() => { setActiveTab('public'); setSelectedOrder(null); }} 
            className={`py-2.5 text-[8px] font-black uppercase rounded-lg transition-all flex flex-col items-center gap-1 ${activeTab === 'public' ? 'bg-blue-600 text-white shadow-xl' : 'text-slate-500'}`}
          >
            <span>🌐</span>
            <span>Биржа</span>
            {publicBoard.length > 0 && <span className="bg-blue-400 text-white text-[7px] px-1.5 rounded-full">{publicBoard.length}</span>}
          </button>
          <button 
            onClick={() => { setActiveTab('earnings'); setSelectedOrder(null); }} 
            className={`py-2.5 text-[8px] font-black uppercase rounded-lg transition-all flex flex-col items-center gap-1 ${activeTab === 'earnings' ? 'bg-green-600 text-white shadow-xl' : 'text-slate-500'}`}
          >
            <span>💰</span>
            <span>Заработок</span>
          </button>
        </div>
      </div>

      {/* CONTENT */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-40 no-scrollbar">
        
        {/* Вкладка заработка - улучшенная */}
        {activeTab === 'earnings' && (
          <div className="space-y-4 animate-in fade-in">
            {/* Общая статистика */}
            <div className="bg-gradient-to-br from-green-600 to-green-800 p-6 rounded-3xl shadow-2xl">
              <h3 className="text-[10px] font-black uppercase tracking-widest opacity-80 mb-4">Общий заработок</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-3xl font-black">{formatPrice(earningsData.totalConfirmed)}</div>
                  <div className="text-[9px] uppercase opacity-70">Подтверждено</div>
                </div>
                <div>
                  <div className="text-2xl font-black text-green-200">{formatPrice(earningsData.totalPreliminary)}</div>
                  <div className="text-[9px] uppercase opacity-70">Предварительно</div>
                </div>
              </div>

              {/* Прогресс-бар */}
              <div className="mt-4 pt-4 border-t border-white/20">
                <div className="flex justify-between text-[9px] mb-2">
                  <span>Подтверждено рейсов</span>
                  <span>{earningsData.confirmedTrips} из {earningsData.totalTrips}</span>
                </div>
                <div className="w-full h-3 bg-white/20 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-white rounded-full transition-all duration-500"
                    style={{ width: `${earningsData.totalTrips > 0 ? (earningsData.confirmedTrips / earningsData.totalTrips) * 100 : 0}%` }}
                  />
                </div>
              </div>

              {/* Ожидает проверки */}
              {earningsData.totalTrips - earningsData.confirmedTrips > 0 && (
                <div className="mt-3 bg-white/10 rounded-xl p-3 flex justify-between items-center">
                  <span className="text-[10px]">⏳ На проверке:</span>
                  <span className="font-black text-yellow-300">
                    +{formatPrice(earningsData.totalPreliminary - earningsData.totalConfirmed)}
                  </span>
                </div>
              )}
            </div>

            {/* Быстрая статистика */}
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-[#12192c] p-4 rounded-2xl border border-white/5 text-center">
                <div className="text-2xl font-black">{earningsData.totalTrips}</div>
                <div className="text-[8px] text-slate-500 uppercase">Всего рейсов</div>
              </div>
              <div className="bg-[#12192c] p-4 rounded-2xl border border-green-500/20 text-center">
                <div className="text-2xl font-black text-green-400">{earningsData.confirmedTrips}</div>
                <div className="text-[8px] text-slate-500 uppercase">Подтверждено</div>
              </div>
              <div className="bg-[#12192c] p-4 rounded-2xl border border-orange-500/20 text-center">
                <div className="text-2xl font-black text-orange-400">{earningsData.totalTrips - earningsData.confirmedTrips}</div>
                <div className="text-[8px] text-slate-500 uppercase">На проверке</div>
              </div>
            </div>

            {/* История по заказам */}
            <div className="space-y-3">
              <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">История по объектам</h4>
              {orders.filter(o => (o.evidences || []).some(e => e.driverName === driverName)).map(order => {
                const myEvs = (order.evidences || []).filter(e => e.driverName === driverName);
                const confirmed = myEvs.filter(e => e.confirmed).length;
                const pricePerTrip = order.assetRequirements[0]?.contractorPrice || 0;
                
                return (
                  <div key={order.id} className="bg-[#12192c] p-4 rounded-2xl border border-white/5">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <div className="font-black text-sm uppercase">{order.address}</div>
                        <div className="text-[9px] text-slate-500">{formatDateTime(order.createdAt)}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-green-400 font-black">{formatPrice(confirmed * pricePerTrip)}</div>
                        <div className="text-[8px] text-slate-500">{confirmed} / {myEvs.length} рейсов</div>
                      </div>
                    </div>
                    <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-green-500 transition-all" 
                        style={{ width: `${myEvs.length > 0 ? (confirmed / myEvs.length) * 100 : 0}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Список заказов */}
        {activeTab !== 'earnings' && !activeSelectedOrder && (
          displayJobs.length > 0 ? (
            displayJobs.map(({ order: job, type }, idx) => {
              const priceForDriver = job.assetRequirements.find(r => r.type === type)?.contractorPrice || 0;
              const isUrgent = new Date(job.scheduledTime).getTime() - Date.now() < 3600000;
              
              return (
                <button 
                  key={idx} 
                  onClick={() => setSelectedOrder({ order: job, type })} 
                  className={`w-full text-left rounded-3xl border-2 bg-[#12192c] p-5 shadow-xl transition-all active:scale-[0.98] ${
                    activeTab === 'company' ? 'border-orange-500/30' : 
                    isUrgent ? 'border-red-500/30' : 'border-white/5'
                  }`}
                >
                  {isUrgent && (
                    <div className="flex items-center gap-2 mb-2">
                      <span className="bg-red-500 text-white text-[8px] font-black px-2 py-0.5 rounded-full animate-pulse">СРОЧНО</span>
                    </div>
                  )}
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-[9px] font-black text-blue-400 uppercase tracking-widest">{job.customer}</span>
                    <span className="text-[8px] font-black uppercase bg-black/20 px-2 py-1 rounded-md">{job.status}</span>
                  </div>
                  <h4 className="text-lg font-black mb-3 leading-tight uppercase">{job.address}</h4>
                  
                  {/* Ограничения */}
                  {job.restrictions && (
                    <div className="flex gap-2 mb-3">
                      {job.restrictions.hasHeightLimit && <span className="text-[9px] bg-yellow-500/20 text-yellow-400 px-2 py-0.5 rounded">↕️ Высота</span>}
                      {job.restrictions.hasNarrowEntrance && <span className="text-[9px] bg-yellow-500/20 text-yellow-400 px-2 py-0.5 rounded">↔️ Узкий</span>}
                      {job.restrictions.hasPermitRegime && <span className="text-[9px] bg-yellow-500/20 text-yellow-400 px-2 py-0.5 rounded">🎫 Пропуск</span>}
                    </div>
                  )}
                  
                  <div className="flex justify-between items-end pt-3 border-t border-white/5">
                    <div>
                      <div className="text-2xl font-black text-green-400">{formatPrice(priceForDriver)}</div>
                      <div className="text-[8px] text-slate-500 uppercase">за рейс</div>
                    </div>
                    <div className="text-right">
                      <span className="text-[9px] font-black uppercase text-slate-500 flex items-center gap-1">
                        {type === AssetType.LOADER ? '🚜' : '🚛'} {type}
                      </span>
                      <div className="text-[8px] text-slate-600">{formatDateTime(job.scheduledTime)}</div>
                    </div>
                  </div>
                </button>
              );
            })
          ) : (
            <div className="text-center py-20 opacity-20">
              <div className="text-6xl mb-4">
                {activeTab === 'mine' ? '🚛' : activeTab === 'company' ? '📨' : '🌐'}
              </div>
              <div className="text-[10px] font-black uppercase tracking-[0.4em]">
                {activeTab === 'mine' ? 'Нет активных работ' : 'Нет доступных заказов'}
              </div>
            </div>
          )
        )}

        {/* Детали заказа */}
        {activeTab !== 'earnings' && activeSelectedOrder && (
          <div className="animate-in slide-in-from-bottom-8 space-y-4">
            <button 
              onClick={() => { setSelectedOrder(null); setCapturedPhotos([]); }} 
              className="text-[10px] font-black uppercase text-slate-500 flex items-center gap-2"
            >
              ← Назад к списку
            </button>
            
            <div className="bg-[#12192c] rounded-3xl p-6 border border-blue-500/30 shadow-2xl">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-2xl font-black uppercase leading-tight">{activeSelectedOrder.address}</h3>
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mt-1">
                    {formatDateTime(activeSelectedOrder.scheduledTime)}
                  </p>
                </div>
                <div className={`px-3 py-1 rounded-lg text-[9px] font-black uppercase ${
                  activeSelectedOrder.status === OrderStatus.IN_PROGRESS ? 'bg-green-500/20 text-green-400' : 'bg-blue-500/20 text-blue-400'
                }`}>
                  {activeSelectedOrder.status}
                </div>
              </div>

              {/* Карточка заработка */}
              <div className="bg-gradient-to-r from-green-600/20 to-blue-600/20 p-4 rounded-2xl border border-white/10 mb-6">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-xl font-black text-white">{driverEvidences.length}</div>
                    <div className="text-[8px] text-slate-400 uppercase">Рейсов</div>
                  </div>
                  <div>
                    <div className="text-xl font-black text-green-400">{confirmedCount}</div>
                    <div className="text-[8px] text-slate-400 uppercase">Засчитано</div>
                  </div>
                  <div>
                    <div className="text-xl font-black text-yellow-400">{pendingCount}</div>
                    <div className="text-[8px] text-slate-400 uppercase">На проверке</div>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-white/10 flex justify-between">
                  <div>
                    <div className="text-[8px] text-slate-500 uppercase">Предварительно</div>
                    <div className="text-lg font-black text-slate-300">{formatPrice(currentOrderEarnings.preliminary)}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-[8px] text-slate-500 uppercase">Подтверждено</div>
                    <div className="text-lg font-black text-green-400">{formatPrice(currentOrderEarnings.confirmed)}</div>
                  </div>
                </div>
              </div>

              {/* Если назначен - показываем функционал работы */}
              {activeSelectedOrder.assignedDrivers.includes(driverName) ? (
                <div className="space-y-4">
                  {selectedOrder?.type === AssetType.TRUCK ? (
                    <>
                      {/* Выбор типа фото */}
                      <div>
                        <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-2 block">
                          Тип фотографии
                        </label>
                        <div className="grid grid-cols-4 gap-2">
                          {Object.entries(photoTypeLabels).map(([key, label]) => (
                            <button
                              key={key}
                              type="button"
                              onClick={() => setPhotoType(key as any)}
                              className={`py-2 px-2 rounded-xl text-[8px] font-black uppercase transition-all ${
                                photoType === key 
                                  ? 'bg-blue-600 text-white' 
                                  : 'bg-white/5 text-slate-400 border border-white/10'
                              }`}
                            >
                              {label}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Кнопка фото */}
                      <label className="block w-full cursor-pointer">
                        <div className={`bg-blue-600 p-8 rounded-3xl flex flex-col items-center gap-3 border-b-8 border-blue-800 shadow-2xl active:scale-95 transition-all ${isCapturing ? 'opacity-50' : ''}`}>
                          <span className="text-5xl">{isCapturing ? '⏳' : '📸'}</span>
                          <span className="font-black uppercase tracking-widest text-white text-sm">
                            {isCapturing ? 'Обработка...' : 'Сделать фото'}
                          </span>
                          <span className="text-[9px] opacity-70">{photoTypeLabels[photoType]}</span>
                        </div>
                        <input 
                          ref={fileInputRef}
                          type="file" 
                          accept="image/*" 
                          capture="environment" 
                          className="hidden" 
                          onChange={handleFileCapture}
                          disabled={isCapturing}
                        />
                      </label>

                      {/* Превью сделанных фото */}
                      {capturedPhotos.length > 0 && (
                        <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
                          <div className="flex justify-between items-center mb-3">
                            <span className="text-[10px] font-black uppercase text-slate-400">
                              Фото для рейса ({capturedPhotos.length})
                            </span>
                            <button 
                              onClick={() => setCapturedPhotos([])}
                              className="text-[9px] text-red-400 font-black uppercase"
                            >
                              Очистить
                            </button>
                          </div>
                          <div className="flex gap-2 overflow-x-auto pb-2">
                            {capturedPhotos.map((photo, i) => (
                              <div key={i} className="relative shrink-0">
                                <img src={photo.url} className="w-16 h-16 object-cover rounded-lg" />
                                <span className="absolute bottom-0 left-0 right-0 bg-black/70 text-[7px] text-center py-0.5 rounded-b-lg">
                                  {photoTypeLabels[photo.type as keyof typeof photoTypeLabels] || photo.type}
                                </span>
                              </div>
                            ))}
                          </div>
                          <button
                            onClick={submitTrip}
                            className="w-full mt-3 bg-green-600 hover:bg-green-500 text-white py-4 rounded-2xl text-[11px] font-black uppercase tracking-widest shadow-lg border-b-4 border-green-800 active:border-b-0 active:translate-y-1 transition-all"
                          >
                            ✅ Отправить рейс на проверку
                          </button>
                        </div>
                      )}

                      {/* GPS статус */}
                      <div className={`p-3 rounded-xl text-[9px] font-black uppercase flex items-center justify-between ${
                        currentPosition ? 'bg-green-500/10 text-green-400 border border-green-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'
                      }`}>
                        <span>{currentPosition ? '📍 Геолокация определена' : '⚠️ GPS недоступен'}</span>
                        {currentPosition && (
                          <span className="text-slate-500">±{Math.round(currentPosition.accuracy)}м</span>
                        )}
                      </div>

                      {/* История рейсов */}
                      {driverEvidences.length > 0 && (
                        <div className="mt-6">
                          <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-3">
                            История смены ({driverEvidences.length} рейсов)
                          </h4>
                          <div className="space-y-2 max-h-60 overflow-y-auto">
                            {driverEvidences.slice().reverse().map((ev, i) => (
                              <div key={ev.id} className="flex items-center gap-3 bg-white/5 p-3 rounded-xl border border-white/5">
                                <div className="w-12 h-12 bg-black rounded-lg overflow-hidden shrink-0">
                                  <img 
                                    src={ev.photos?.[0]?.url || ev.photo} 
                                    className="w-full h-full object-cover" 
                                    alt={`Рейс ${ev.tripNumber || driverEvidences.length - i}`}
                                  />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="text-[10px] font-black uppercase text-slate-300">
                                    Рейс #{ev.tripNumber || driverEvidences.length - i}
                                  </div>
                                  <div className="text-[8px] text-slate-500">
                                    {new Date(ev.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                  </div>
                                </div>
                                <div className={`px-2 py-1 rounded-lg text-[8px] font-bold uppercase ${
                                  ev.confirmed ? 'bg-green-500/20 text-green-400' : 'bg-orange-500/20 text-orange-400'
                                }`}>
                                  {ev.confirmed ? '✅ Принят' : '⏳ Проверка'}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </>
                  ) : (
                    /* Для погрузчика - упрощённый интерфейс */
                    <div className="bg-green-500/10 p-6 rounded-2xl text-center border border-green-500/20">
                      <span className="text-4xl block mb-3">🚜</span>
                      <span className="text-[11px] font-black uppercase text-green-400">Смена открыта</span>
                      <p className="text-[9px] text-slate-400 mt-2">Работайте на объекте. Менеджер отслеживает прогресс.</p>
                    </div>
                  )}
                  
                  {/* Кнопка завершения */}
                  <button 
                    onClick={() => { 
                      if (confirm('Завершить работу на этом объекте?')) { 
                        onFinishWork(activeSelectedOrder.id); 
                        setSelectedOrder(null); 
                      } 
                    }} 
                    className="w-full bg-slate-800 hover:bg-slate-700 p-5 rounded-3xl text-[10px] font-black uppercase text-slate-400 mt-4 transition-all"
                  >
                    🏁 Завершить работу на объекте
                  </button>
                </div>
              ) : (
                /* Если не назначен - кнопка принятия */
                <button 
                  onClick={() => { 
                    onAcceptJob(activeSelectedOrder.id, driverContractorId, selectedOrder!.type); 
                    // Не закрываем - даём подтверждение
                    alert('✅ Заявка отправлена! Ожидайте подтверждения менеджера.');
                  }} 
                  className="w-full bg-gradient-to-r from-blue-600 to-blue-700 p-10 rounded-3xl text-2xl font-black uppercase tracking-widest border-b-8 border-blue-800 shadow-2xl active:scale-95 active:border-b-0 transition-all"
                >
                  ✅ ОТКЛИКНУТЬСЯ
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DriverPortal;
